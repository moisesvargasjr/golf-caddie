# Handoff — Golf Caddie · Digital Scorecard Redesign

## Overview
A redesign of an existing iOS golf shot-tracking app. The user marks every shot they take during a round; pins are dropped on a satellite map; the app totals score, computes club averages, and stores a logbook of past rounds.

The chosen direction — **"The Fairway Logbook"** — adopts an old-school printed-scorecard aesthetic: cream paper stock, dark green "ink", serif headlines (Georgia), monospace numerals, and ink-stamp badges. The design has both **light and dark** modes (dark uses deep forest stock with warm cream "chalk").

Five core screens are designed and prototyped: Home, Active Round (the main in-play screen), Hole Detail / Shot Review, Round Summary, Rounds List (Logbook).

## About the Design Files
The files in this bundle are **design references created in HTML/React** — prototypes that show the intended look, layout, and behavior. They are not production code to copy directly.

Your task is to **recreate these designs in the target codebase's existing environment** — almost certainly **SwiftUI** for an iOS golf app — using its established patterns, components, and libraries. Use Apple Maps / MapKit for the real satellite map (the prototype uses an illustrative SVG placeholder). The HTML files are reference only.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and interactions are final. The developer should recreate the UI pixel-perfectly: exact hex values, exact font families and weights, exact paddings, exact stamp / pin / button styling.

The one exception is the **map**: the prototype uses an SVG illustration of a generic golf hole. Production should use **Apple MapKit** in satellite mode with the same overlay treatment (paper-textured floating cards on top of the map; same shot-pin design).

---

## Design Tokens

All tokens live in `app/state.jsx` in the prototype.

### Palette — Light (default day mode)
```
paper:      #EFE6D2   // warm cream stock (background)
paperDark:  #E5DBC2   // bottom of paper gradient / inset rows
ink:        #1B3A29   // dark forest green — primary text & strokes
ink2:       #3D5A48   // secondary text
ink3:       #7A8676   // tertiary / metadata
rule:       rgba(27,58,41,0.15)    // dividers
ruleStrong: rgba(27,58,41,0.35)
red:        #A8392A   // stamp red — bogey/over-par/alert accent
flag:       #C24A2D   // log-shot button, latest pin
cardShadow: 3px 3px 0 rgba(27,58,41,0.18)
```

### Palette — Dark
```
paper:      #16241C   // deep forest stock (background)
paperDark:  #0F1A14
ink:        #EFE5C9   // warm cream "chalk" — primary text & strokes
ink2:       #B5AC8E
ink3:       #6A6754
rule:       rgba(239,229,201,0.16)
ruleStrong: rgba(239,229,201,0.4)
red:        #E07A55   // warmer red for dark
flag:       #E07A55
cardShadow: 3px 3px 0 rgba(0,0,0,0.55)
```

Mode follows `Auto` by default: system color scheme OR clock-based (≥18:00 or <06:00 → dark). Manual Light/Dark override available in Tweaks.

### Typography
```
serif:  Georgia, "Times New Roman", "Charter"    // display, hole numbers, course names
mono:   SF Mono, Menlo, "Courier New"            // numerals, labels, stamps
ui:     -apple-system, system-ui                 // buttons, status bar
```

Scale (sizes in pt, weight via `fontWeight: 700` unless otherwise noted):
- **Masthead** (Home title): serif 64pt, weight 700, line-height 0.95, letter-spacing -2
- **Course name** (Summary): serif 38pt italic, weight 700, letter-spacing -1.2
- **Hole numeral** (Hole detail): serif 76pt, weight 700, letter-spacing -3
- **Score hero** (Summary): serif 108pt, weight 700, letter-spacing -4.5, lineHeight 0.85, tabular-nums
- **Distance hero** (Active Round): serif 64pt, weight 700, letter-spacing -2.5, tabular-nums
- **Section title** (e.g. "The Ledger."): serif 22pt italic, weight 700
- **Body large**: serif 17pt, weight 700
- **Stamp / pill label**: mono 10pt, weight 700, letter-spacing 1.2–1.4, uppercase
- **Metadata** (date strips): mono 10–11pt, weight 700, letter-spacing 1.2

Important text treatments:
- The word "The" at the start of titles is **italic, weight 400** (e.g. *The* Fairway Logbook, *The* Ledger.) — this italic-the pattern is the visual signature.
- All numerals use `font-variant-numeric: tabular-nums`.

### Spacing
Standard inset: **24px horizontal** for content; **20px** for cards with map/full-width content; **12px** for floating overlays on a map.

Vertical rhythm: 14px between rule and content; 18px between sections.

### Border Radius
- **Cards / paper**: `2px` (very small — keeps the printed look)
- **Buttons / pills**: `4px` (primary CTA) or `2px` (secondary)
- **Bottom sheet**: `28px` top corners
- Note: this design intentionally uses *much smaller* radii than typical iOS apps. Don't apply Apple's default `cornerRadius: 12`.

### Shadows
Paper cards use an **offset hard shadow** (no blur):
- Light: `3px 3px 0 rgba(27,58,41,0.18)`
- Dark: `3px 3px 0 rgba(0,0,0,0.55)`

This gives the "printed card sitting on a desk" feel. Don't use soft drop shadows.

### Stamp Component
A rectangular "ink-stamped" badge used throughout:
```
border: 1.2px solid <color>
color: <color>
padding: 3px 8px
fontFamily: mono
fontSize: 10pt
fontWeight: 700
letter-spacing: 1.2
text-transform: uppercase
border-radius: 2px
```
Used for: status labels (CONFIRMED, +37, TRIPLE BOGEY), section markers (CADDIE · NO. 247, VOL. III · 2026, OFFICIAL CARD).

### Paper Texture
Subtle background pattern layered onto the cream/forest base:
```css
background-image:
  radial-gradient(circle at 20% 10%, rgba(<inkRgb>,0.04), transparent 50%),
  radial-gradient(circle at 80% 80%, rgba(<inkRgb>,0.03), transparent 50%),
  repeating-linear-gradient(45deg, transparent 0 11px, rgba(<inkRgb>,0.012) 11px 12px),
  linear-gradient(180deg, <paper> 0%, <paperDark> 100%);
```
Where `<inkRgb>` is `27,58,41` (light) or `239,229,201` (dark). Adjust the cross-hatch opacity to `0.018` in dark mode.

---

## Screens

### 1. Home — "The Fairway Logbook"

**Purpose**: Landing screen. Show last round at a glance, allow starting a new round or browsing past rounds.

**Layout** (top → bottom):
1. **Header row** (top, 28px from edges): two-column row.
   - Left: small ink-bordered "CADDIE · NO. 247" stamp.
   - Right: red dot + "G2 LINKED" mono text (G2 = Even Realities AR glasses connection status). Color: ink2.
2. **Masthead** (below header, large): serif 64pt italic-the-then-bold display reading "*The* / Fairway / Logbook." in three lines. Below it, mono uppercase date + weather strip ("TUES · MAY 19 · 2026 · 76°F · 6MPH SW").
3. **Horizontal rule** (1.5px solid ink, full-width minus 28px insets).
4. **Last entry block** (tappable → opens Summary): 
   - Mono label "LAST ENTRY · TAP TO REVIEW" 
   - Italic serif course name "The Welk Oaks G.C." 22pt
   - Score row: "SCORE" mono label + giant serif "91" (64pt), then a red `+37` stamp, then duration "1h 52m" right-aligned
   - 9-cell mini scorecard ribbon (hole #s and scores in a row, bordered top + bottom with thin rule)
5. **Bottom action area** (positioned absolute, bottom 36px):
   - Row: "THE BAG · 14 CLUBS" stamp + "LOGBOOK ›" link (right-aligned). Tap → Rounds list.
   - **Primary CTA**: full-width button, background = ink, text color = paper, padding 22px, border-radius 4px, hard-shadow `0 4px 0 rgba(0,0,0,0.25)`. Text: italic "Begin" + bold "new round" (serif 24pt, weight 700, letter-spacing 0.5). Tap → starts new round, navigates to Active Round.

**Interactions**:
- Tap "Begin new round" → reset round state, set currentHole = 1, navigate to Active Round
- Tap "Last entry" block → navigate to Summary (showing previously played round)
- Tap "Logbook ›" → navigate to Rounds list

---

### 2. Active Round — full-bleed map + control deck

**Purpose**: The most-used screen. Mark each shot with the chosen club. Heavy emphasis on the map and minimum friction to log a shot.

**Layout** (full-bleed, three z-layers):

**Layer 1: Full-bleed map** (background, the entire viewport)
- Apple MapKit satellite mode, top-down view of the current hole
- Dimmed 18% with a black overlay for legibility of paper cards
- Shot pins drawn on top: circles with `box-shadow: 0 2px 6px rgba(0,0,0,0.4), 0 0 0 2px rgba(255,255,255,0.95)`, white-paper background for prior shots, flag-orange (`#C24A2D`) for the latest. Pin labels are the shot number (1, 2, 3...) in bold sans-serif inside the circle. Latest pin is sized 32px, prior 28px. Pins are connected by a dashed white line (`stroke-dasharray: 3 3, opacity 0.7`).
- **Swipe horizontally** on the map to change hole (prev/next).

**Layer 2: Top overlays** (z-index 30, top 56px from top)
- **Left paper card**: hole pill. Padding 6px 4px 6px 10px. Contains:
  - `‹` Home button (italic serif glyph, ink2 color)
  - `‹` prev-hole button (mono, disabled at hole 1)
  - Center column: "Hole I" (serif 17pt italic, weight 700) + "PAR 4 · 419 YDS" mono caption
  - `›` next-hole button (disabled at hole 9)
- **Right paper card**: "Lying N OF N" stamp text using flag/red color.

**Layer 3: Distance card** (top 120px, left 12px)
- Paper card, padding 12px 16px 10px, min-width 168.
- "TO PIN" mono label
- Serif 64pt tabular number ("142") + small "yd" mono suffix
- Hairline rule
- Two-column FRONT / BACK with smaller distances (mono 14pt, tabular)

**Layer 4: Bottom sheet** (z-index 30, bottom 0, full-width)
- Paper background, border-radius 28px top corners, padding 18px 20px 32px, hard top-shadow `0 -8px 40px rgba(0,0,0,0.5)`. Includes the same paper-texture cross-hatch.
- Drag handle (40×3, rule color, centered).
- "SELECTED" mono label + "7 Iron" serif italic name + "avg 150 yd" mono caption + "↺ UNDO" stamp button right-aligned (disabled when no shots).
- **Horizontal scroll club row** (14 clubs: Dr, 3W, 5H, 4i–9i, PW, GW, SW, LW, Pt). Each cell:
  - Min-width 50px
  - 8px 4px padding
  - Right border (rule color) between cells
  - Club abbreviation in serif 16pt italic
  - Average distance below in mono 9pt
  - **Selected cell**: background inverts to ink, text becomes paper
  - Mask-image gradient at edges to fade clubs off-screen
  - Top + bottom borders (1.5px ink, 1px ink)
- **Action row** (3 buttons):
  - `↺` Undo (50×50, ink border, transparent bg)
  - **"Log shot"** primary (flex 1, height 50, flag-color bg, paper text, italic "Log" + bold "shot", serif 20pt, hard shadow). Tap → addShot(selected club).
  - `⚠` Penalty (50×50, ink border, flag-color glyph)
- Caption: "‹ SWIPE FOR PREV  ·  NEXT HOLE ›" hint (mono 9pt, ink3).

**Interactions**:
- Tap club → updates selectedClub
- Tap "Log shot" → push new shot onto current hole's shot array, generate pin coords (next pin moves toward green, slight horizontal jitter), increment "Lying N"
- Tap Undo (either icon) → pop last shot
- Tap `‹`/`›` → change hole
- Horizontal swipe on map → change hole (>50px deltaX triggers)
- Tap Home `‹` → back to Home

---

### 3. Hole Detail / Shot Review

**Purpose**: Review and edit shots for a specific hole. The map should be **large** because the primary action is dragging misplaced pins.

**Standard view layout**:
1. Nav row: "‹ ROUND" mono link + "CONFIRMED" stamp.
2. **Hole heading**: "Hole" (italic serif 18pt, ink2) + giant numeral "I" (serif 76pt) on one baseline. To the right: PAR · YDS mono caption. Below: current score number (serif 26pt, red if over par) + status stamp ("Triple bogey" / "Bogey" / "Birdie" / etc.).
3. **Big map area**: 360px tall, bordered (1.5px solid ink), border-radius 2px, hard cardShadow. Contains:
   - The same paper-style satellite map with shot pins
   - **"↗ EXPAND" button** in top-right corner (paper card, mono 10pt stamp style) → enters fullscreen edit mode
   - "TAP A PIN TO EDIT" helper in bottom-left
   - Selected pin popover in bottom-right (shows club + distance + lie)
4. **The Ledger**: serif italic header + entry count. Table with columns:
   - NO. (Roman numeral, serif italic 16pt)
   - CLUB (serif 17pt)
   - YDS (mono 17pt tabular, right-aligned)
   - LIE (mono 10pt uppercase, right-aligned)
   - Header row: 2px top ink border, 1px rule bottom border, mono 9pt labels
   - Each row: 1px rule bottom border
   - Selected row gets a `rgba(<inkRgb>,0.04)` background tint
   - Footer row: "Total dist." (italic) + sum, 2px top ink border

**Expanded (fullscreen) view layout**:
- Full-bleed map (no border, no paper bg around it)
- Top-left: "↙ COLLAPSE" paper button + top-right: hole label paper card
- Bottom (when a pin is selected): paper card showing pin #, club, distance, lie, and a "Drag to fix" stamp
- Bottom (no selection): white-shadowed mono "TAP A PIN TO EDIT · DRAG TO REPOSITION" caption

**Interactions**:
- Tap a map pin → highlights it (color becomes flag-orange, size 32 instead of 26), shows popover
- Tap a ledger row → also selects/deselects that shot
- Tap Expand → fullscreen edit mode
- Tap Collapse → return to standard view
- (Production should support **drag** to reposition pins in expanded mode)

---

### 4. Round Summary — "Official Card"

**Purpose**: Final scorecard for a completed round. Reads like a paper card from the clubhouse.

**Layout**:
1. Nav row: "‹ ROUNDS" mono link + "SHARE" mono link right.
2. **Masthead** (centered):
   - Red stamp "OFFICIAL CARD · NO. 247"
   - Course name in two lines: bold italic serif (e.g. "The Welk Oaks") 38pt + lighter italic "Golf Course" 22pt (`fontWeight: 400`, ink2)
   - Date strip mono 10pt: "MAY · 18 · 2026 · ESCONDIDO, CA"
3. **Double-rule divider**: 2px ink, 3px gap, 1px ink (the classic newspaper rule).
4. **Big score block**: 
   - Left: "FINAL · 18 HOLES" mono label + giant serif "91" (108pt, letter-spacing -4.5, tabular)
   - Right (baseline-aligned to bottom): red `+37` stamp + duration/shots metadata
5. Thin half-opacity rule.
6. **"Front nine." scorecard table**: 
   - Header row: HOLE / I / II / ... / IX / OUT (2px ink top, 1px ink bottom, mono labels)
   - PAR row: light text
   - YOU row: each cell holds the score in a **shape badge**:
     - Birdie (d = -1 or better): **circle** with red border, red text
     - Par (d = 0): plain number, no border, ink color
     - Bogey (d = +1): square with ink border, ink text
     - Double+ (d ≥ +2): square with red border, red text
     - Badge size 22×22, border 1.5px, inner number 13pt mono
   - OUT cell: red, larger (16pt)
7. **Legend strip**: ○ BIRDIE  □ BOGEY  ▢ DOUBLE+ (mono 10pt, ink2, with mini swatch icons)
8. **Signature line**: a bottom-bordered area (1px ink, height 28) with a cursive "—" placeholder, "SIGNED · PLAYER" mono caption below.

**Interactions**:
- Tap back → Rounds list
- Tap Share → (placeholder; not wired)
- Tap a hole in the scorecard → (future: jump to Hole Detail for that hole)

---

### 5. Rounds List — "The Logbook"

**Purpose**: Browse past rounds. List-driven, dense, but typographically rich.

**Layout**:
1. Nav row: "‹ HOME" link + "VOL. III · 2026" stamp.
2. **Title**: serif italic "The / Logbook." 64pt. Below: mono caption "23 ENTRIES · AVG 92 · BEST 87".
3. **Column header rule**: 2px ink top + 1px ink bottom, with mono labels "DATE ↓" / "COURSE" / "SCORE" spread justify-between.
4. **Round rows** (each tappable → Summary):
   - Left column (48px wide): mon-name mono label (e.g. "MAY") + serif day "18" (26pt, tabular)
   - Middle column: italic serif course name (17pt) + mono caption "DURATION · 18 HOLES" (or "PRACTICE")
   - Right column: serif score (28pt, tabular) + red mono `+37` delta below; or "— —" for practice rounds
   - Row separator: 1px rule

**Interactions**:
- Tap row → setViewingRoundId(id), navigate to Summary

---

## Map Component (production note)

Replace the SVG placeholder with **Apple MapKit** in satellite mode:
- Zoom locked appropriately for the current hole (auto-fit to tee + green + shot bounding box, with padding)
- Custom annotation views for shot pins:
  - 28pt circle, white background (light mode), 2pt white inner ring, drop shadow `0 2px 6px rgba(0,0,0,0.4)`
  - Number label centered, SF Pro Display weight 700
  - Latest pin: 32pt, flag-orange (`#C24A2D`) background
- Polyline connecting pins: white, 1.5pt, dashed (3pt dash, 3pt gap, opacity 0.7)
- Slight dim overlay (`rgba(0,0,0,0.18)`) on top of the map view so paper cards remain legible
- Disable rotation; allow pinch-zoom in **expanded** (fullscreen) mode only
- Drag-to-reposition pins is handled by long-press → drag gesture on annotation views

---

## State Management

In SwiftUI: use a single `@ObservableObject` `RoundStore` with these properties:

```swift
class RoundStore: ObservableObject {
  @Published var screen: Screen = .home  // .home, .round, .hole, .summary, .rounds
  @Published var currentHole: Int = 1
  @Published var selectedClub: String = "7i"
  @Published var shotsPerHole: [Int: [Shot]] = [:]   // hole# → shots
  @Published var viewingRoundId: String?  = nil
  @Published var theme: ThemeMode = .auto
  @Published var inkHue: InkHue = .green
  @Published var accent: Accent = .vintageRed
  @Published var units: Units = .yards
  @Published var numerals: Numerals = .roman
}

struct Shot: Identifiable {
  let id = UUID()
  let club: String          // "7 Iron"
  let shortClub: String     // "7i"
  let yds: Int
  let lie: Lie              // .fairway, .rough, .green, .bunker, .hole
  var coordinate: CLLocationCoordinate2D
}
```

Methods:
- `addShot(club:)` → captures current GPS location, appends Shot to `shotsPerHole[currentHole]`
- `undoShot()` → pops last shot
- `resetRound()` → clears all shots, sets currentHole = 1
- `setCurrentHole(_ hole: Int)` → navigates between holes

Theme resolution:
- If `theme == .auto`: dark when (`UIScreen.main.traitCollection.userInterfaceStyle == .dark` OR current hour ≥ 18 OR < 6).
- Otherwise use explicit theme.

Persist all settings (theme, inkHue, accent, units, numerals) via `UserDefaults` or `@AppStorage`. Persist `shotsPerHole` and round history via Core Data or SwiftData.

---

## Animations & Transitions

- Club selection: subtle scale (none required, just background flip ink ↔ paper)
- Shot logged: pin should **appear with a slight scale-in** (0.6 → 1.0) over ~180ms, paired with a brief flash of the "Lying N" counter
- Hole change (swipe): map should crossfade (200ms) — not a slide
- Expand → fullscreen: map container animates from inset frame to fullscreen over 280ms ease-out
- Screen navigation: standard iOS `NavigationStack` push/pop is fine; no custom transition required

---

## Tweaks (in-app settings)

The prototype exposes these as a Tweaks panel for designer iteration. In production these belong in a Settings screen:

- **Theme mode**: Auto / Light / Dark
- **Ink color**: Forest green / Black / Navy (overrides `ink` token only)
- **Accent**: Vintage red / Amber / Forest (overrides `red` + `flag` tokens)
- **Units**: Yards / Meters
- **Hole numerals**: Roman / Arabic

Implement these as `@AppStorage`-backed enums and apply at render time via the palette + helper functions.

---

## Reference Files in this Bundle

```
prototype/
├── Golf Caddie.html                  # entry — open this in browser to see the prototype
├── app/
│   ├── state.jsx                     # palette, theme hook, RoundStore-equivalent
│   ├── atoms.jsx                     # Frame, Stamp, PaperCard, CourseMap, helpers
│   ├── home.jsx                      # Home screen
│   ├── round.jsx                     # Active round screen (the big one)
│   ├── hole.jsx                      # Hole detail + expanded edit mode
│   ├── summary.jsx                   # Round summary card
│   ├── rounds.jsx                    # Logbook list
│   ├── tweaks.jsx                    # Settings/tweaks panel content
│   └── tweaks-panel.jsx              # Generic tweaks shell (not user-facing in app)
```

Read these files in order:
1. `state.jsx` — for the data model and theme logic
2. `atoms.jsx` — for the Stamp, PaperCard, CourseMap primitives
3. The five screen files — each is self-contained

---

## Build Order Recommendation

1. **Design tokens first**: implement the palette enums, font registry, Stamp view, PaperCard view, paper-texture background.
2. **Home screen** (simplest, validates the type system).
3. **Rounds list + Summary** (read-only, easy data flow).
4. **Active Round** (most interactive; the core loop).
5. **Hole Detail** (last; depends on shot data from Active Round).

---

## Out of Scope (not designed in this pass)

- Bag editor screen
- Settings screen (proper iOS settings; the Tweaks panel is a placeholder)
- Onboarding / first-launch flow
- Apple Watch app
- AR glasses (G2) handoff UI
- Course-selection screen (the prototype assumes a single course)
- Multi-player / friends features

When you get to these, ask for design first — don't extrapolate.
