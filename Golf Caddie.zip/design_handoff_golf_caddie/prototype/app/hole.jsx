// hole.jsx — Hole detail / shot review.
// Bigger map with EXPAND button → fullscreen edit mode.
// Selected shot pin can be tapped, shows edit popover.
function HoleDetail() {
  const { P, fonts, setScreen, currentHole, shotsPerHole } = useScorecard();
  const labelHole = useHoleLabel();
  const dist = useDistance();
  const [expanded, setExpanded] = React.useState(false);
  const [selectedShot, setSelectedShot] = React.useState(null);

  const shots = shotsPerHole[currentHole] || [
    { club: 'Driver',   shortClub: 'Dr', yds: 215, lie: 'Fairway', x: 50, y: 92 },
    { club: '7 Iron',   shortClub: '7i', yds: 148, lie: 'Rough',   x: 58, y: 70 },
    { club: 'P. Wedge', shortClub: 'PW', yds: 71,  lie: 'Green',   x: 62, y: 50 },
    { club: 'Putter',   shortClub: 'Pt', yds: 18,  lie: 'Hole',    x: 64, y: 30 },
  ];

  const pins = shots.map((s, i) => ({
    x: s.x, y: s.y, label: String(i + 1),
    color: i === selectedShot ? P.flag : P.paper,
    textColor: i === selectedShot ? '#fff' : P.ink,
    size: i === selectedShot ? 32 : 26,
  }));

  const holeData = [
    { par: 4, yds: 419 }, { par: 3, yds: 152 }, { par: 4, yds: 412 },
    { par: 5, yds: 538 }, { par: 4, yds: 387 }, { par: 3, yds: 168 },
    { par: 4, yds: 401 }, { par: 3, yds: 145 }, { par: 4, yds: 415 },
  ];
  const cur = holeData[currentHole - 1];
  const score = shots.length || 0;
  const dScore = score - cur.par;
  const totalDist = shots.reduce((sum, s) => sum + s.yds, 0);

  if (expanded) {
    // ── Fullscreen map edit mode ─────────────────────────
    return (
      <Frame fullBleed>
        <div style={{ position: 'absolute', inset: 0 }}>
          <CourseMap variant="satellite" pins={pins} onPinClick={(i) => setSelectedShot(i)} />
          <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.15)', pointerEvents: 'none' }} />
        </div>

        {/* top — exit + hole id */}
        <div style={{
          position: 'absolute', top: STATUS_BAR_H + 2, left: 12, right: 12, zIndex: 30,
          display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8,
        }}>
          <button onClick={() => setExpanded(false)} style={{
            background: P.paper, color: P.ink, border: `1.2px solid ${P.ink}`,
            boxShadow: P.cardShadow, borderRadius: 2, cursor: 'pointer',
            padding: '8px 14px', fontFamily: fonts.mono, fontSize: 11, fontWeight: 700, letterSpacing: 1.2, textTransform: 'uppercase',
          }}>↙ Collapse</button>
          <div style={{
            background: P.paper, color: P.ink, border: `1.2px solid ${P.ink}`,
            boxShadow: P.cardShadow, borderRadius: 2,
            padding: '8px 14px', fontFamily: fonts.serif, fontSize: 17, fontWeight: 700, fontStyle: 'italic',
          }}>Hole {labelHole(currentHole)}</div>
        </div>

        {/* bottom — selected pin info */}
        {selectedShot != null && shots[selectedShot] && (
          <div style={{
            position: 'absolute', bottom: 20, left: 12, right: 12, zIndex: 30,
            background: P.paper, color: P.ink, border: `1.2px solid ${P.ink}`,
            boxShadow: P.cardShadow, borderRadius: 2,
            padding: '14px 18px',
            display: 'flex', alignItems: 'center', gap: 14,
          }}>
            <div style={{
              fontFamily: fonts.serif, fontSize: 30, fontWeight: 700, color: P.flag,
              fontStyle: 'italic', lineHeight: 1,
            }}>{selectedShot + 1}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: fonts.serif, fontSize: 18, fontWeight: 700 }}>{shots[selectedShot].club}</div>
              <div style={{ fontFamily: fonts.mono, fontSize: 10, color: P.ink2, fontWeight: 700, letterSpacing: 1, marginTop: 2 }}>
                {dist.fmt(shots[selectedShot].yds)} {dist.unit.toUpperCase()} · FROM {shots[selectedShot].lie.toUpperCase()}
              </div>
            </div>
            <Stamp color={P.ink}>Drag to fix</Stamp>
          </div>
        )}

        {selectedShot == null && (
          <div style={{
            position: 'absolute', bottom: 28, left: 12, right: 12, zIndex: 30,
            textAlign: 'center', fontFamily: fonts.mono, fontSize: 11, color: '#fff', fontWeight: 700, letterSpacing: 1.4,
            textShadow: '0 1px 4px rgba(0,0,0,0.8)',
          }}>TAP A PIN TO EDIT · DRAG TO REPOSITION</div>
        )}
      </Frame>
    );
  }

  // ── Standard view ──────────────────────────────────────
  return (
    <Frame>
      <div style={{ height: '100%', overflowY: 'auto', paddingBottom: 24 }}>
        {/* nav */}
        <div style={{ padding: `${STATUS_BAR_H + 6}px 24px 0`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <button onClick={() => setScreen('round')} style={{
            background: 'transparent', border: 'none', cursor: 'pointer',
            fontFamily: fonts.mono, fontSize: 11, color: P.ink, fontWeight: 700, letterSpacing: 1.4, padding: 0,
          }}>‹ ROUND</button>
          <Stamp color={P.ink}>Confirmed</Stamp>
        </div>

        {/* hole heading */}
        <div style={{ padding: '14px 24px 0' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 12 }}>
            <div style={{ fontFamily: fonts.serif, fontSize: 18, fontStyle: 'italic', color: P.ink2, fontWeight: 400 }}>Hole</div>
            <div style={{ fontFamily: fonts.serif, fontSize: 76, fontWeight: 700, color: P.ink, lineHeight: 0.85, letterSpacing: -3 }}>
              {labelHole(currentHole)}
            </div>
            <div style={{ flex: 1, marginBottom: 6 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontFamily: fonts.mono, fontSize: 10, color: P.ink2, fontWeight: 700, letterSpacing: 1.2 }}>
                <span>PAR {cur.par}</span><span style={{ color: P.ink3 }}>·</span><span>{dist.fmt(cur.yds)} {dist.unit.toUpperCase()}</span>
              </div>
              {score > 0 && (
                <div style={{ marginTop: 8, display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ fontFamily: fonts.serif, fontSize: 26, fontWeight: 700, color: dScore > 0 ? P.red : P.ink, letterSpacing: -0.8 }}>{score}</div>
                  <Stamp color={dScore > 0 ? P.red : P.ink}>
                    {dScore === 0 ? 'Par' : dScore === 1 ? 'Bogey' : dScore === 2 ? 'Double' : dScore >= 3 ? `+${dScore}` : dScore === -1 ? 'Birdie' : `${dScore}`}
                  </Stamp>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* big map */}
        <div style={{ padding: '14px 20px 0' }}>
          <div style={{
            border: `1.5px solid ${P.ink}`, borderRadius: 2, height: 360, position: 'relative', overflow: 'hidden',
            boxShadow: P.cardShadow,
          }}>
            <CourseMap variant="paper" pins={pins} onPinClick={(i) => setSelectedShot(i)} />
            {/* expand button */}
            <button onClick={() => setExpanded(true)} style={{
              position: 'absolute', top: 8, right: 8, zIndex: 5,
              background: P.paper, color: P.ink, border: `1.2px solid ${P.ink}`,
              borderRadius: 2, padding: '6px 10px', cursor: 'pointer',
              fontFamily: fonts.mono, fontSize: 10, fontWeight: 700, letterSpacing: 1.2, textTransform: 'uppercase',
            }}>↗ Expand</button>
            {/* helper */}
            <div style={{
              position: 'absolute', bottom: 6, left: 8,
              background: P.paper, padding: '3px 8px',
              fontFamily: fonts.mono, fontSize: 9, fontWeight: 700, color: P.ink, letterSpacing: 1.2,
            }}>TAP A PIN TO EDIT</div>
            {/* selected popover */}
            {selectedShot != null && shots[selectedShot] && (
              <div style={{
                position: 'absolute', bottom: 8, right: 8,
                background: P.paper, color: P.ink, border: `1.2px solid ${P.ink}`,
                boxShadow: P.cardShadow, borderRadius: 2, padding: '8px 12px',
              }}>
                <div style={{ fontFamily: fonts.serif, fontSize: 15, fontWeight: 700, fontStyle: 'italic' }}>{shots[selectedShot].club}</div>
                <div style={{ fontFamily: fonts.mono, fontSize: 10, color: P.ink2, fontWeight: 700, letterSpacing: 1 }}>
                  {dist.fmt(shots[selectedShot].yds)}{dist.short} · {shots[selectedShot].lie.toUpperCase()}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* shot ledger */}
        <div style={{ padding: '18px 24px 0' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 8 }}>
            <div style={{ fontFamily: fonts.serif, fontSize: 22, fontWeight: 700, fontStyle: 'italic' }}>The Ledger.</div>
            <div style={{ fontFamily: fonts.mono, fontSize: 10, color: P.ink2, fontWeight: 700, letterSpacing: 1.2 }}>{shots.length} ENTRIES</div>
          </div>

          <div style={{ borderTop: `2px solid ${P.ink}` }}>
            <div style={{
              display: 'grid', gridTemplateColumns: '32px 1fr 70px 60px',
              padding: '6px 0', borderBottom: `1px solid ${P.rule}`,
              fontFamily: fonts.mono, fontSize: 9, fontWeight: 700, color: P.ink3, letterSpacing: 1.4,
            }}>
              <div>NO.</div>
              <div>CLUB</div>
              <div style={{ textAlign: 'right' }}>{dist.unit.toUpperCase()}</div>
              <div style={{ textAlign: 'right' }}>LIE</div>
            </div>
            {shots.length === 0 && (
              <div style={{ padding: '20px 0', textAlign: 'center', fontFamily: fonts.mono, fontSize: 11, color: P.ink3, fontWeight: 700, letterSpacing: 1.2 }}>NO SHOTS RECORDED</div>
            )}
            {shots.map((s, i) => (
              <div key={i}
                onClick={() => setSelectedShot(i === selectedShot ? null : i)}
                style={{
                  display: 'grid', gridTemplateColumns: '32px 1fr 70px 60px',
                  padding: '10px 0', borderBottom: `1px solid ${P.rule}`,
                  alignItems: 'center', cursor: 'pointer',
                  background: selectedShot === i ? `rgba(${P.inkRgb},0.04)` : 'transparent',
                }}>
                <div style={{ fontFamily: fonts.serif, fontSize: 16, fontWeight: 700, fontStyle: 'italic', color: P.ink2 }}>{toRoman(i + 1)}</div>
                <div style={{ fontFamily: fonts.serif, fontSize: 17, fontWeight: 700, color: P.ink }}>{s.club}</div>
                <div style={{ textAlign: 'right', fontFamily: fonts.mono, fontSize: 17, fontWeight: 700, color: P.ink, fontVariantNumeric: 'tabular-nums' }}>{dist.fmt(s.yds)}</div>
                <div style={{ textAlign: 'right', fontFamily: fonts.mono, fontSize: 10, color: P.ink2, fontWeight: 700, letterSpacing: 0.8 }}>{s.lie.toUpperCase()}</div>
              </div>
            ))}
          </div>

          {shots.length > 0 && (
            <div style={{
              marginTop: 4, display: 'grid', gridTemplateColumns: '32px 1fr 70px 60px',
              padding: '6px 0', borderTop: `2px solid ${P.ink}`,
            }}>
              <div></div>
              <div style={{ fontFamily: fonts.serif, fontStyle: 'italic', fontSize: 14, fontWeight: 700, color: P.ink2 }}>Total dist.</div>
              <div style={{ textAlign: 'right', fontFamily: fonts.mono, fontSize: 14, fontWeight: 700, color: P.ink, fontVariantNumeric: 'tabular-nums' }}>{dist.fmt(totalDist)}</div>
              <div></div>
            </div>
          )}
        </div>
      </div>
    </Frame>
  );
}

Object.assign(window, { HoleDetail });
