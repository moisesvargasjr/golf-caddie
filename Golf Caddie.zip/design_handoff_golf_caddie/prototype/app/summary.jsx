// summary.jsx — Round summary / official card view.
function Summary() {
  const { P, fonts, setScreen, viewingRoundId } = useScorecard();
  const labelHole = useHoleLabel();
  const dist = useDistance();

  // pick a round: viewing existing past round, or fall back to demo r1
  const round = PAST_ROUNDS.find(r => r.id === viewingRoundId) || PAST_ROUNDS[0];
  // synthesize holes if missing (for the simpler entries)
  const holes = round.holes || [
    { h:1, par:4, score:5, d:1 }, { h:2, par:3, score:4, d:1 },
    { h:3, par:4, score:5, d:1 }, { h:4, par:5, score:6, d:1 },
    { h:5, par:4, score:5, d:1 }, { h:6, par:3, score:4, d:1 },
    { h:7, par:4, score:6, d:2 }, { h:8, par:3, score:4, d:1 },
    { h:9, par:4, score:5, d:1 },
  ];
  const out = holes.reduce((s, r) => s + r.score, 0);
  const outPar = holes.reduce((s, r) => s + r.par, 0);
  const outD = out - outPar;

  const scoreShape = (d) => d <= -1 ? 'circle' : d === 0 ? 'none' : 'square';
  const scoreColor = (d) => d <= -1 || d >= 2 ? P.red : P.ink;

  return (
    <Frame>
      <div style={{ height: '100%', overflowY: 'auto', paddingBottom: 28 }}>
        {/* nav */}
        <div style={{ padding: `${STATUS_BAR_H + 6}px 24px 0`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <button onClick={() => setScreen('rounds')} style={{
            background: 'transparent', border: 'none', cursor: 'pointer',
            fontFamily: fonts.mono, fontSize: 11, color: P.ink, fontWeight: 700, letterSpacing: 1.4, padding: 0,
          }}>‹ ROUNDS</button>
          <div style={{ fontFamily: fonts.mono, fontSize: 11, color: P.ink, fontWeight: 700, letterSpacing: 1.4 }}>SHARE</div>
        </div>

        {/* masthead */}
        <div style={{ padding: '20px 24px 0', textAlign: 'center' }}>
          <Stamp color={P.red}>OFFICIAL CARD · NO. 247</Stamp>
          <div style={{
            fontFamily: fonts.serif, fontSize: 38, fontWeight: 700, letterSpacing: -1.2,
            lineHeight: 1, marginTop: 12, fontStyle: 'italic',
          }}>{round.course.split(' G.C.')[0].split(' — ')[0]}</div>
          <div style={{
            fontFamily: fonts.serif, fontSize: 22, fontWeight: 400, letterSpacing: -0.4,
            color: P.ink2, fontStyle: 'italic',
          }}>Golf Course</div>
          <div style={{
            fontFamily: fonts.mono, fontSize: 10, color: P.ink2, fontWeight: 700, letterSpacing: 1.4,
            marginTop: 8,
          }}>{round.date.replace(' ', ' · ')} · {round.year} · ESCONDIDO, CA</div>
        </div>

        {/* double rule */}
        <div style={{ margin: '20px 24px 0' }}>
          <div style={{ height: 2, background: P.ink }} />
          <div style={{ height: 1, background: P.ink, marginTop: 3 }} />
        </div>

        {/* big score */}
        <div style={{ padding: '20px 24px 0', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontFamily: fonts.mono, fontSize: 10, color: P.ink3, fontWeight: 700, letterSpacing: 1.4 }}>FINAL · 18 HOLES</div>
            <div style={{
              fontFamily: fonts.serif, fontSize: 108, fontWeight: 700, letterSpacing: -4.5,
              lineHeight: 0.85, color: P.ink, marginTop: 4, fontVariantNumeric: 'tabular-nums',
            }}>{round.score || '—'}</div>
          </div>
          <div style={{ paddingBottom: 18, textAlign: 'right' }}>
            {round.d && <Stamp color={P.red} size="md">{round.d}</Stamp>}
            <div style={{
              marginTop: 8, fontFamily: fonts.mono, fontSize: 11, color: P.ink2, fontWeight: 700, letterSpacing: 1.2,
            }}>{round.dur}H · {round.score || 0} SHOTS</div>
          </div>
        </div>

        <div style={{ height: 1, background: P.ink, opacity: 0.5, margin: '20px 24px 0' }} />

        {/* scorecard */}
        <div style={{ padding: '16px 20px 0' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 10 }}>
            <div style={{ fontFamily: fonts.serif, fontSize: 22, fontWeight: 700, fontStyle: 'italic' }}>Front nine.</div>
            <div style={{ fontFamily: fonts.mono, fontSize: 11, color: P.ink2, fontWeight: 700 }}>OUT {out} · <span style={{ color: P.red }}>+{outD}</span></div>
          </div>

          <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: fonts.mono, fontSize: 13, fontVariantNumeric: 'tabular-nums' }}>
            <thead>
              <tr style={{ borderTop: `2px solid ${P.ink}`, borderBottom: `1px solid ${P.ink}` }}>
                <th style={{ padding: '6px 4px', textAlign: 'left', fontSize: 9, fontWeight: 700, color: P.ink2, letterSpacing: 1.4 }}>HOLE</th>
                {holes.map(r => (
                  <th key={r.h} style={{ padding: '6px 0', fontWeight: 700, color: P.ink, fontSize: 12 }}>{labelHole(r.h)}</th>
                ))}
                <th style={{ padding: '6px 4px', textAlign: 'right', fontSize: 9, fontWeight: 700, color: P.ink2, letterSpacing: 1.4 }}>OUT</th>
              </tr>
            </thead>
            <tbody>
              <tr style={{ borderBottom: `1px solid ${P.rule}` }}>
                <td style={{ padding: '7px 4px', fontSize: 10, color: P.ink2, fontWeight: 700, letterSpacing: 1 }}>PAR</td>
                {holes.map(r => (
                  <td key={r.h} style={{ padding: '7px 0', textAlign: 'center', color: P.ink2, fontWeight: 700 }}>{r.par}</td>
                ))}
                <td style={{ padding: '7px 4px', textAlign: 'right', color: P.ink2, fontWeight: 700 }}>{outPar}</td>
              </tr>
              <tr>
                <td style={{ padding: '10px 4px', fontSize: 10, color: P.ink2, fontWeight: 700, letterSpacing: 1 }}>YOU</td>
                {holes.map(r => {
                  const sh = scoreShape(r.d);
                  const col = scoreColor(r.d);
                  return (
                    <td key={r.h} style={{ padding: '10px 0', textAlign: 'center' }}>
                      <span style={{
                        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                        width: 22, height: 22, color: col, fontWeight: 700,
                        border: sh === 'none' ? 'none' : `1.5px solid ${col}`,
                        borderRadius: sh === 'circle' ? '50%' : 2,
                      }}>{r.score}</span>
                    </td>
                  );
                })}
                <td style={{ padding: '10px 4px', textAlign: 'right', color: P.red, fontWeight: 700, fontSize: 16 }}>{out}</td>
              </tr>
            </tbody>
          </table>

          {/* legend */}
          <div style={{
            display: 'flex', gap: 14, marginTop: 14, padding: '10px 0', borderTop: `1px solid ${P.rule}`,
            fontFamily: fonts.mono, fontSize: 10, color: P.ink2, fontWeight: 700, letterSpacing: 1,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
              <div style={{ width: 14, height: 14, borderRadius: '50%', border: `1.5px solid ${P.red}` }} />
              BIRDIE
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
              <div style={{ width: 14, height: 14, borderRadius: 2, border: `1.5px solid ${P.ink}` }} />
              BOGEY
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
              <div style={{ width: 14, height: 14, borderRadius: 2, border: `1.5px solid ${P.red}` }} />
              DOUBLE+
            </div>
          </div>
        </div>

        {/* signature */}
        <div style={{ padding: '20px 24px 0' }}>
          <div style={{
            borderBottom: `1px solid ${P.ink}`, height: 28,
            fontFamily: '"Brush Script MT", "Snell Roundhand", cursive', fontSize: 22, color: P.ink, fontStyle: 'italic',
            display: 'flex', alignItems: 'flex-end', paddingLeft: 8,
          }}>—</div>
          <div style={{ fontFamily: fonts.mono, fontSize: 9, color: P.ink2, fontWeight: 700, letterSpacing: 1.4, marginTop: 4 }}>SIGNED · PLAYER</div>
        </div>
      </div>
    </Frame>
  );
}

Object.assign(window, { Summary });
