// state.jsx — palette, theme hook, base frame, shared atoms
// All scorecard prototype screens consume this.

// ─── Palettes ─────────────────────────────────────────────
const SC_LIGHT = {
  paper: '#EFE6D2', paperDark: '#E5DBC2',
  ink: '#1B3A29', ink2: '#3D5A48', ink3: '#7A8676',
  rule: 'rgba(27,58,41,0.15)', ruleStrong: 'rgba(27,58,41,0.35)',
  red: '#A8392A', flag: '#C24A2D',
  cardShadow: '3px 3px 0 rgba(27,58,41,0.18)',
  inkRgb: '27,58,41',
};
const SC_DARK = {
  paper: '#16241C', paperDark: '#0F1A14',
  ink: '#EFE5C9', ink2: '#B5AC8E', ink3: '#6A6754',
  rule: 'rgba(239,229,201,0.16)', ruleStrong: 'rgba(239,229,201,0.4)',
  red: '#E07A55', flag: '#E07A55',
  cardShadow: '3px 3px 0 rgba(0,0,0,0.55)',
  inkRgb: '239,229,201',
};
const FONTS = {
  serif: 'Georgia, "Times New Roman", "Charter", serif',
  mono: '"SF Mono", "Menlo", "Courier New", monospace',
  ui: '-apple-system, system-ui, sans-serif',
};

// ─── Theme + tweaks store (global) ────────────────────────
const ScorecardCtx = React.createContext(null);

const DEFAULT_TWEAKS = /*EDITMODE-BEGIN*/{
  "themeMode": "auto",
  "inkHue": "green",
  "accent": "vintage-red",
  "units": "yds",
  "numerals": "roman"
}/*EDITMODE-END*/;

// ink hue overrides — replace the green default with another tone
const INK_HUES = {
  green:  { light: '#1B3A29', dark: '#EFE5C9' },
  black:  { light: '#1F1B14', dark: '#F1EAD8' },
  navy:   { light: '#1A2A4A', dark: '#D9E2F4' },
};
const ACCENTS = {
  'vintage-red': '#A8392A',
  'amber':       '#C77721',
  'forest':      '#3A6B3C',
};

function applyTweaks(base, tweaks, isDark) {
  const inkSwap = INK_HUES[tweaks.inkHue]?.[isDark ? 'dark' : 'light'];
  const out = { ...base };
  if (inkSwap) out.ink = inkSwap;
  const accent = ACCENTS[tweaks.accent];
  if (accent) { out.red = accent; out.flag = accent; }
  return out;
}

// Hook used by every screen
function useScorecard() {
  return React.useContext(ScorecardCtx);
}

// Provider that wraps the whole app
function ScorecardProvider({ children, initialScreen = 'home' }) {
  const [tweaks, setTweaksState] = React.useState(DEFAULT_TWEAKS);

  // Auto-mode: check system + time of day. After 18:30 or before 6am, force dark.
  const computeDark = React.useCallback((mode) => {
    if (mode === 'light') return false;
    if (mode === 'dark') return true;
    const h = new Date().getHours();
    const nightByClock = h >= 18 || h < 6;
    const systemDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
    return nightByClock || systemDark;
  }, []);

  const [isDark, setIsDark] = React.useState(() => computeDark(DEFAULT_TWEAKS.themeMode));
  React.useEffect(() => { setIsDark(computeDark(tweaks.themeMode)); }, [tweaks.themeMode, computeDark]);

  const setTweak = React.useCallback((kOrObj, v) => {
    setTweaksState(prev => {
      const next = typeof kOrObj === 'object' ? { ...prev, ...kOrObj } : { ...prev, [kOrObj]: v };
      try {
        window.parent.postMessage({ type: '__edit_mode_set_keys', edits: next }, '*');
      } catch (e) { /* not embedded */ }
      return next;
    });
  }, []);

  // App-level navigation + round state
  const [screen, setScreen] = React.useState(initialScreen);
  const [viewingRoundId, setViewingRoundId] = React.useState(null);
  const [currentHole, setCurrentHole] = React.useState(1);
  const [selectedClub, setSelectedClub] = React.useState('7i');

  // shotsPerHole[hole] = [{club, yds, x, y}, ...]
  const [shotsPerHole, setShotsPerHole] = React.useState(() => ({
    1: [
      { club: 'Driver', shortClub: 'Dr', yds: 215, lie: 'Fairway', x: 50, y: 92 },
      { club: '7 Iron', shortClub: '7i', yds: 148, lie: 'Rough',   x: 58, y: 70 },
      { club: 'P. Wedge', shortClub: 'PW', yds: 71, lie: 'Green',  x: 62, y: 50 },
      { club: 'Putter', shortClub: 'Pt', yds: 18, lie: 'Hole',     x: 64, y: 30 },
    ],
    2: [], 3: [], 4: [], 5: [], 6: [], 7: [], 8: [], 9: [],
  }));

  const addShot = React.useCallback((club, shortClub) => {
    setShotsPerHole(prev => {
      const list = prev[currentHole] || [];
      // place new pin slightly above last one toward the green
      const last = list[list.length - 1];
      const x = last ? last.x + (Math.random() * 6 - 3) : 50;
      const y = last ? Math.max(20, last.y - 12 - Math.random() * 6) : 92;
      const yds = Math.round(80 + Math.random() * 120);
      const next = [...list, { club, shortClub, yds, lie: 'Fairway', x, y }];
      return { ...prev, [currentHole]: next };
    });
  }, [currentHole]);

  const undoShot = React.useCallback(() => {
    setShotsPerHole(prev => {
      const list = prev[currentHole] || [];
      if (list.length === 0) return prev;
      return { ...prev, [currentHole]: list.slice(0, -1) };
    });
  }, [currentHole]);

  const resetRound = React.useCallback(() => {
    setShotsPerHole({ 1:[],2:[],3:[],4:[],5:[],6:[],7:[],8:[],9:[] });
    setCurrentHole(1);
  }, []);

  // Resolve final palette (base + tweaks)
  const base = isDark ? SC_DARK : SC_LIGHT;
  const P = applyTweaks(base, tweaks, isDark);

  const value = {
    P, isDark, fonts: FONTS, tweaks, setTweak,
    screen, setScreen,
    viewingRoundId, setViewingRoundId,
    currentHole, setCurrentHole,
    selectedClub, setSelectedClub,
    shotsPerHole, addShot, undoShot, resetRound,
  };
  return <ScorecardCtx.Provider value={value}>{children}</ScorecardCtx.Provider>;
}

Object.assign(window, {
  SC_LIGHT, SC_DARK, FONTS,
  ScorecardCtx, ScorecardProvider, useScorecard,
  ACCENTS, INK_HUES,
});
