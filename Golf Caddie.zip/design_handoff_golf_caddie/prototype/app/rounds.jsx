// rounds.jsx — Logbook list of past rounds
function Rounds() {
  const { P, fonts, setScreen, setViewingRoundId } = useScorecard();

  const openRound = (id) => {
    setViewingRoundId(id);
    setScreen('summary');
  };

  return (
    <Frame>
      <div style={{ height: '100%', overflowY: 'auto', paddingBottom: 28 }}>
        {/* nav */}
        <div style={{ padding: `${STATUS_BAR_H + 6}px 24px 0`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <button onClick={() => setScreen('home')} style={{
            background: 'transparent', border: 'none', cursor: 'pointer',
            fontFamily: fonts.mono, fontSize: 11, color: P.ink, fontWeight: 700, letterSpacing: 1.4,
            padding: 0,
          }}>‹ HOME</button>
          <Stamp color={P.ink}>VOL. III · 2026</Stamp>
        </div>

        {/* title */}
        <div style={{ padding: '14px 24px 0' }}>
          <div style={{
            fontFamily: fonts.serif, fontSize: 64, fontWeight: 700, letterSpacing: -2,
            lineHeight: 0.9, fontStyle: 'italic',
          }}>The<br/>Logbook.</div>
          <div style={{
            marginTop: 8, fontFamily: fonts.mono, fontSize: 10, color: P.ink2, fontWeight: 700, letterSpacing: 1.4,
          }}>23 ENTRIES · AVG 92 · BEST 87</div>
        </div>

        {/* sort row */}
        <div style={{
          margin: '20px 24px 0', display: 'flex', justifyContent: 'space-between',
          borderTop: `2px solid ${P.ink}`, borderBottom: `1px solid ${P.ink}`,
          padding: '8px 0',
        }}>
          <div style={{ fontFamily: fonts.mono, fontSize: 10, color: P.ink, fontWeight: 700, letterSpacing: 1.4 }}>DATE ↓</div>
          <div style={{ fontFamily: fonts.mono, fontSize: 10, color: P.ink3, fontWeight: 700, letterSpacing: 1.4 }}>COURSE</div>
          <div style={{ fontFamily: fonts.mono, fontSize: 10, color: P.ink3, fontWeight: 700, letterSpacing: 1.4 }}>SCORE</div>
        </div>

        {/* entries */}
        <div style={{ padding: '0 24px' }}>
          {PAST_ROUNDS.map((r) => {
            const [mon, day] = r.date.split(' ');
            return (
              <div key={r.id}
                onClick={() => openRound(r.id)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 12,
                  padding: '14px 0', borderBottom: `1px solid ${P.rule}`,
                  cursor: 'pointer',
                }}>
                <div style={{ width: 48, flexShrink: 0 }}>
                  <div style={{ fontFamily: fonts.mono, fontSize: 9, color: P.ink2, fontWeight: 700, letterSpacing: 1.2 }}>{mon}</div>
                  <div style={{ fontFamily: fonts.serif, fontSize: 26, fontWeight: 700, color: P.ink, lineHeight: 1, marginTop: 2, fontVariantNumeric: 'tabular-nums' }}>{day}</div>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontFamily: fonts.serif, fontSize: 17, fontWeight: 700, fontStyle: 'italic', color: P.ink, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.course}</div>
                  <div style={{ fontFamily: fonts.mono, fontSize: 10, color: P.ink2, fontWeight: 600, letterSpacing: 0.8, marginTop: 2 }}>{r.dur} · {r.practice ? 'PRACTICE' : '18 HOLES'}</div>
                </div>
                <div style={{ textAlign: 'right', minWidth: 56 }}>
                  {r.score ? (
                    <>
                      <div style={{ fontFamily: fonts.serif, fontSize: 28, fontWeight: 700, color: P.ink, lineHeight: 1, letterSpacing: -0.8, fontVariantNumeric: 'tabular-nums' }}>{r.score}</div>
                      <div style={{ fontFamily: fonts.mono, fontSize: 10, color: P.red, fontWeight: 700, marginTop: 2 }}>{r.d}</div>
                    </>
                  ) : (
                    <div style={{ fontFamily: fonts.mono, fontSize: 9, color: P.ink3, fontWeight: 700, letterSpacing: 1.2 }}>— —</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </Frame>
  );
}

Object.assign(window, { Rounds });
