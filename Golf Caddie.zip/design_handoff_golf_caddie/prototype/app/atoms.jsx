// atoms.jsx — Frame, Stamp, PaperCard, helpers, CourseMap
// Built on top of state.jsx; consumes useScorecard() for palette + theme.

// ─── Frame ────────────────────────────────────────────────
// Phone-sized viewport. We don't draw a device bezel here — the prototype
// fills the browser window and uses the safe area for status bar offset.
function Frame({ children, fullBleed = false }) {
  const { P, isDark, fonts } = useScorecard();
  const bg = fullBleed ? '#000' : P.paper;

  // paper texture for non-fullbleed screens
  const paperTexture = fullBleed ? {} : {
    backgroundImage: `
      radial-gradient(circle at 20% 10%, rgba(${P.inkRgb},0.04), transparent 50%),
      radial-gradient(circle at 80% 80%, rgba(${P.inkRgb},0.03), transparent 50%),
      repeating-linear-gradient(45deg, transparent 0 11px, rgba(${P.inkRgb},${isDark ? 0.018 : 0.012}) 11px 12px),
      linear-gradient(180deg, ${P.paper} 0%, ${P.paperDark} 100%)
    `,
  };

  return (
    <div style={{
      width: '100%', height: '100%', position: 'relative', overflow: 'hidden',
      background: bg, color: P.ink,
      fontFamily: fonts.ui, WebkitFontSmoothing: 'antialiased',
      ...paperTexture,
    }}>
      {children}
    </div>
  );
}

// Status bar offset — every screen pads top by this much (44 + 10)
const STATUS_BAR_H = 54;

// ─── Stamp ────────────────────────────────────────────────
function Stamp({ children, color, style = {}, size = 'sm' }) {
  const { P, fonts } = useScorecard();
  const c = color || P.ink;
  const sizes = {
    sm: { fontSize: 10, padding: '3px 8px', letter: 1.2 },
    md: { fontSize: 12, padding: '4px 10px', letter: 1.4 },
  };
  const s = sizes[size];
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: s.padding, border: `1.2px solid ${c}`,
      color: c, fontFamily: fonts.mono, fontSize: s.fontSize, fontWeight: 700,
      letterSpacing: s.letter, textTransform: 'uppercase',
      borderRadius: 2,
      ...style,
    }}>{children}</div>
  );
}

// ─── PaperCard ────────────────────────────────────────────
function PaperCard({ children, style = {}, onClick, asButton = false }) {
  const { P } = useScorecard();
  return (
    <div onClick={onClick} role={asButton ? 'button' : undefined} style={{
      background: P.paper, color: P.ink,
      border: `1.2px solid ${P.ink}`,
      boxShadow: P.cardShadow, borderRadius: 2,
      cursor: onClick ? 'pointer' : 'default',
      transition: 'transform .08s, box-shadow .08s',
      ...style,
    }}>{children}</div>
  );
}

// Roman numeral helper
function toRoman(n) {
  const map = [['X',10],['IX',9],['V',5],['IV',4],['I',1]];
  let r = '';
  for (const [s, v] of map) { while (n >= v) { r += s; n -= v; } }
  return r;
}

// hole label respecting tweak
function useHoleLabel() {
  const { tweaks } = useScorecard();
  return (n) => tweaks.numerals === 'roman' ? toRoman(n) : String(n);
}

// distance unit helper
function useDistance() {
  const { tweaks } = useScorecard();
  return {
    fmt: (yds) => tweaks.units === 'm' ? Math.round(yds * 0.9144) : Math.round(yds),
    unit: tweaks.units === 'm' ? 'm' : 'yd',
    short: tweaks.units === 'm' ? 'm' : 'y',
  };
}

// ─── CourseMap (illustrative top-down) ────────────────────
// Same SVG hole as the exploration, parameterized for palette.
function CourseMap({
  variant = 'satellite',
  pins = [],
  rotation = 0, zoom = 1,
  showAttribution = false,
  style = {},
  onPinClick,
}) {
  const palette = variant === 'satellite'
    ? { rough: '#2b3a25', fairway: '#4a6b35', green: '#7ba84a', bunker: '#d8c98a', tree: '#1a2618', path: '#8a8478' }
    : { rough: '#d8d0b8', fairway: '#bfc99a', green: '#9eb878', bunker: '#e8dcb3', tree: '#7d8a5a', path: '#a89b7d' };

  return (
    <div style={{
      position: 'relative', overflow: 'hidden',
      background: palette.rough, width: '100%', height: '100%',
      ...style,
    }}>
      <svg
        viewBox="0 0 400 800"
        preserveAspectRatio="xMidYMid slice"
        style={{ position: 'absolute', inset: 0, width: '100%', height: '100%',
          transform: `scale(${zoom}) rotate(${rotation}deg)`, transformOrigin: 'center 60%' }}
      >
        <ellipse cx="40" cy="200" rx="80" ry="160" fill={palette.tree} opacity="0.75" />
        <ellipse cx="370" cy="380" rx="60" ry="140" fill={palette.tree} opacity="0.8" />
        <ellipse cx="20" cy="540" rx="50" ry="120" fill={palette.tree} opacity="0.7" />
        <ellipse cx="380" cy="650" rx="55" ry="110" fill={palette.tree} opacity="0.7" />
        <path d="M180 760 C 100 700, 90 580, 130 480 C 165 390, 240 350, 250 260 C 256 190, 220 140, 210 90 C 205 60, 230 40, 260 50 C 290 60, 300 110, 290 170 C 280 240, 240 290, 235 360 C 230 430, 260 510, 250 600 C 244 680, 250 740, 250 780 Z" fill={palette.fairway} />
        <path d="M195 720 C 140 650, 140 560, 175 470 C 205 400, 250 360, 252 270"
          stroke={palette.fairway} strokeWidth="40" fill="none" strokeLinecap="round" opacity="0.5" />
        <ellipse cx="160" cy="340" rx="22" ry="14" fill={palette.bunker} />
        <ellipse cx="285" cy="430" rx="18" ry="22" fill={palette.bunker} />
        <ellipse cx="215" cy="160" rx="14" ry="10" fill={palette.bunker} />
        <ellipse cx="260" cy="110" rx="38" ry="30" fill={palette.green} />
        <path d="M40 800 Q 80 600, 60 400 Q 50 200, 100 50"
          stroke={palette.path} strokeWidth="3" fill="none" opacity="0.6" />
        <rect x="225" y="730" width="50" height="16" rx="3" fill={palette.green} opacity="0.7" />
      </svg>

      {/* flag pin on green */}
      <div style={{ position: 'absolute', left: '65%', top: '14%', transform: 'translate(-50%, -100%)', pointerEvents: 'none' }}>
        <div style={{ width: 2, height: 28, background: '#fff', margin: '0 auto' }} />
        <div style={{ width: 14, height: 10, background: '#ef4444', position: 'absolute', left: 1, top: 2, clipPath: 'polygon(0 0, 100% 50%, 0 100%)' }} />
      </div>

      {/* shot pins */}
      {pins.map((p, i) => (
        <div key={i} style={{
          position: 'absolute', left: `${p.x}%`, top: `${p.y}%`,
          transform: 'translate(-50%, -50%)', zIndex: 2,
        }}>
          {i > 0 && pins[i-1] && (
            <svg style={{
              position: 'absolute', overflow: 'visible', pointerEvents: 'none',
              left: 0, top: 0,
            }}>
              <line
                x1="0" y1="0"
                x2={`${(pins[i-1].x - p.x) * 3.9}`}
                y2={`${(pins[i-1].y - p.y) * 7.9}`}
                stroke="#fff" strokeWidth="1.5"
                strokeDasharray="3 3" opacity="0.7"
              />
            </svg>
          )}
          <div
            onClick={onPinClick ? () => onPinClick(i, p) : undefined}
            style={{
              width: p.size || 28, height: p.size || 28, borderRadius: '50%',
              background: p.color || '#fff',
              color: p.textColor || '#000',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontWeight: 700, fontSize: (p.size || 28) * 0.46,
              boxShadow: '0 2px 6px rgba(0,0,0,0.4), 0 0 0 2px rgba(255,255,255,0.95)',
              fontFamily: '-apple-system, system-ui',
              cursor: onPinClick ? 'pointer' : 'default',
            }}
          >{p.label}</div>
        </div>
      ))}
    </div>
  );
}

// ─── Demo data for past rounds (used by Rounds list + Summary) ─────
const PAST_ROUNDS = [
  {
    id: 'r1', course: 'The Welk Oaks G.C.', date: 'MAY 18', year: '2026',
    dur: '1:52', score: 91, par: 54, d: '+37',
    holes: [
      { h:1, par:4, score:7, d:3 }, { h:2, par:3, score:6, d:3 },
      { h:3, par:4, score:4, d:0 }, { h:4, par:5, score:5, d:0 },
      { h:5, par:4, score:3, d:-1 }, { h:6, par:3, score:4, d:1 },
      { h:7, par:4, score:6, d:2 }, { h:8, par:3, score:4, d:1 },
      { h:9, par:4, score:3, d:-1 },
    ],
  },
  { id:'r2', course: 'Maderas Golf Club',   date: 'MAY 16', year:'2026', dur: '4:12', score: 89, d: '+17' },
  { id:'r3', course: 'Twin Oaks — Practice', date: 'MAY 14', year:'2026', dur: '0:38', practice: true },
  { id:'r4', course: 'Mt. Woodson',          date: 'MAY 10', year:'2026', dur: '4:02', score: 94, d: '+22' },
  { id:'r5', course: 'Welk Oaks — Practice', date: 'MAY 8',  year:'2026', dur: '0:22', practice: true },
  { id:'r6', course: 'The Welk Oaks G.C.',   date: 'APR 28', year:'2026', dur: '1:58', score: 96, d: '+24' },
];

Object.assign(window, { Frame, STATUS_BAR_H, Stamp, PaperCard, CourseMap, toRoman, useHoleLabel, useDistance, PAST_ROUNDS });
