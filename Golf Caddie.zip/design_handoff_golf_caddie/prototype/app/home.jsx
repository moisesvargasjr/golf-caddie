// home.jsx — landing screen
function Home() {
  const { P, fonts, setScreen, resetRound } = useScorecard();
  const beginRound = () => { resetRound(); setScreen('round'); };

  return (
    <Frame>
      {/* masthead */}
      <div style={{ padding: `${STATUS_BAR_H + 6}px 28px 0` }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Stamp color={P.ink}>Caddie · No. 247</Stamp>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 6,
            fontFamily: fonts.mono, fontSize: 11, color: P.ink2, fontWeight: 600,
          }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: P.red }} />
            G2 LINKED
          </div>
        </div>

        <div style={{
          fontFamily: fonts.serif, fontSize: 64, fontWeight: 700, letterSpacing: -2,
          lineHeight: 0.95, marginTop: 18, color: P.ink,
        }}>
          <em style={{ fontStyle: 'italic', fontWeight: 400 }}>The</em>
          <br/>
          Fairway
          <br/>
          Logbook.
        </div>

        <div style={{
          marginTop: 10, fontFamily: fonts.mono, fontSize: 11,
          color: P.ink2, letterSpacing: 1, textTransform: 'uppercase', fontWeight: 600,
        }}>Tues · May 19 · 2026 · 76°F · 6mph SW</div>
      </div>

      {/* rule */}
      <div style={{ height: 1.5, background: P.ink, margin: '24px 28px 0', opacity: 0.85 }} />

      {/* Last entry block */}
      <div style={{ padding: '22px 28px 0', cursor: 'pointer' }}
           onClick={() => { setScreen('summary'); }}>
        <div style={{ fontFamily: fonts.mono, fontSize: 10, color: P.ink3, fontWeight: 700, letterSpacing: 1.4, textTransform: 'uppercase' }}>Last entry · tap to review</div>
        <div style={{
          fontFamily: fonts.serif, fontSize: 22, fontWeight: 700, letterSpacing: -0.4,
          marginTop: 4, fontStyle: 'italic',
        }}>The Welk Oaks G.C.</div>

        <div style={{
          marginTop: 14, display: 'flex', alignItems: 'flex-end', gap: 18,
        }}>
          <div>
            <div style={{ fontFamily: fonts.mono, fontSize: 10, color: P.ink3, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase' }}>Score</div>
            <div style={{
              fontFamily: fonts.serif, fontSize: 64, fontWeight: 700, color: P.ink,
              lineHeight: 1, letterSpacing: -2.5, fontVariantNumeric: 'tabular-nums', marginTop: 2,
            }}>91</div>
          </div>
          <div style={{ paddingBottom: 8 }}>
            <Stamp color={P.red}>+37</Stamp>
          </div>
          <div style={{ paddingBottom: 6, flex: 1, textAlign: 'right' }}>
            <div style={{ fontFamily: fonts.mono, fontSize: 10, color: P.ink3, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase' }}>Duration</div>
            <div style={{ fontFamily: fonts.mono, fontSize: 17, fontWeight: 700, color: P.ink, marginTop: 2 }}>1h 52m</div>
          </div>
        </div>

        {/* mini scorecard ribbon */}
        <div style={{ marginTop: 18, display: 'flex', borderTop: `1px solid ${P.rule}`, borderBottom: `1px solid ${P.rule}` }}>
          {[7,6,4,5,3,4,6,4,3].map((s, i) => (
            <div key={i} style={{
              flex: 1, padding: '8px 0', textAlign: 'center',
              borderRight: i < 8 ? `1px solid ${P.rule}` : 'none',
              fontFamily: fonts.mono,
            }}>
              <div style={{ fontSize: 9, color: P.ink3, fontWeight: 700 }}>{i+1}</div>
              <div style={{ fontSize: 14, color: P.ink, fontWeight: 700, marginTop: 2, fontVariantNumeric: 'tabular-nums' }}>{s}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer: actions */}
      <div style={{ position: 'absolute', bottom: 36, left: 28, right: 28 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <Stamp color={P.ink}>The Bag · 14 clubs</Stamp>
          <div onClick={() => setScreen('rounds')}
            style={{ fontFamily: fonts.mono, fontSize: 11, color: P.ink, fontWeight: 700, textTransform: 'uppercase', cursor: 'pointer', letterSpacing: 1.2 }}>
            Logbook ›
          </div>
        </div>
        <button onClick={beginRound} style={{
          width: '100%', border: 'none', cursor: 'pointer',
          background: P.ink, color: P.paper, borderRadius: 4,
          padding: '22px', textAlign: 'center',
          fontFamily: fonts.serif, fontSize: 24, fontWeight: 700, letterSpacing: 0.5,
          boxShadow: '0 4px 0 rgba(0,0,0,0.25)',
        }}>
          <span style={{ fontStyle: 'italic', fontWeight: 400, opacity: 0.85, marginRight: 6 }}>Begin</span>
          new round
        </button>
      </div>
    </Frame>
  );
}

Object.assign(window, { Home });
