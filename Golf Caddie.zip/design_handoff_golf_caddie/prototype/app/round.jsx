// round.jsx — Active round screen. Full-bleed map + interactive controls.
// Swipe (or arrow buttons) between holes; tap MARK SHOT to add pins;
// undo last shot.

const CLUBS = [
  { c: 'Dr', name: 'Driver',       y: 235 },
  { c: '3W', name: '3 Wood',       y: 215 },
  { c: '5H', name: '5 Hybrid',     y: 195 },
  { c: '4i', name: '4 Iron',       y: 185 },
  { c: '5i', name: '5 Iron',       y: 175 },
  { c: '6i', name: '6 Iron',       y: 165 },
  { c: '7i', name: '7 Iron',       y: 150 },
  { c: '8i', name: '8 Iron',       y: 138 },
  { c: '9i', name: '9 Iron',       y: 125 },
  { c: 'PW', name: 'P. Wedge',     y: 110 },
  { c: 'GW', name: 'Gap Wedge',    y: 95 },
  { c: 'SW', name: 'Sand Wedge',   y: 80 },
  { c: 'LW', name: 'Lob Wedge',    y: 65 },
  { c: 'Pt', name: 'Putter',       y: 10 },
];

function ActiveRound() {
  const {
    P, fonts, setScreen,
    currentHole, setCurrentHole,
    selectedClub, setSelectedClub,
    shotsPerHole, addShot, undoShot,
  } = useScorecard();
  const labelHole = useHoleLabel();
  const dist = useDistance();

  const shots = shotsPerHole[currentHole] || [];
  const selectedClubMeta = CLUBS.find(c => c.c === selectedClub) || CLUBS[6];

  // Per-hole metadata (fixed for the demo course)
  const holeData = [
    { par: 4, yds: 419 }, { par: 3, yds: 152 }, { par: 4, yds: 412 },
    { par: 5, yds: 538 }, { par: 4, yds: 387 }, { par: 3, yds: 168 },
    { par: 4, yds: 401 }, { par: 3, yds: 145 }, { par: 4, yds: 415 },
  ];
  const cur = holeData[currentHole - 1];

  // Pins for the map — use existing shot positions + last one styled as flag-red
  const pins = shots.map((s, i) => ({
    x: s.x, y: s.y, label: String(i + 1),
    color: i === shots.length - 1 ? P.flag : P.paper,
    textColor: i === shots.length - 1 ? '#fff' : P.ink,
    size: i === shots.length - 1 ? 32 : 28,
  }));

  // Live distance simulation: distance to pin = function of last shot Y (top of map = green)
  const lastY = shots.length ? shots[shots.length - 1].y : 92;
  const toPin = Math.max(8, Math.round((lastY - 14) * 4)); // 14% is flag y → distance shrinks

  // ── Swipe handling ──────────────────────────────────────
  const startX = React.useRef(null);
  const onPointerDown = (e) => { startX.current = e.clientX; };
  const onPointerUp = (e) => {
    if (startX.current == null) return;
    const dx = e.clientX - startX.current;
    startX.current = null;
    if (Math.abs(dx) < 50) return;
    if (dx < 0 && currentHole < 9) setCurrentHole(currentHole + 1);
    if (dx > 0 && currentHole > 1) setCurrentHole(currentHole - 1);
  };

  // shorthand paper card recipe
  const paperCard = {
    background: P.paper, color: P.ink,
    border: `1.2px solid ${P.ink}`,
    boxShadow: P.cardShadow, borderRadius: 2,
  };

  const markShot = () => addShot(selectedClubMeta.name, selectedClubMeta.c);

  return (
    <Frame fullBleed>
      {/* full-bleed map */}
      <div
        style={{ position: 'absolute', inset: 0 }}
        onPointerDown={onPointerDown}
        onPointerUp={onPointerUp}
      >
        <CourseMap variant="satellite" pins={pins} />
        <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.18)', pointerEvents: 'none' }} />
      </div>

      {/* Top — hole pill + lying stamp */}
      <div style={{
        position: 'absolute', top: STATUS_BAR_H + 2, left: 12, right: 12, zIndex: 30,
        display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8,
      }}>
        {/* hole pill with prev/next */}
        <div style={{ ...paperCard, padding: '6px 4px 6px 10px', display: 'flex', alignItems: 'center', gap: 4 }}>
          <button
            onClick={() => setScreen('home')}
            style={{ background: 'transparent', border: 'none', cursor: 'pointer', padding: '4px 6px', fontFamily: fonts.serif, fontSize: 16, color: P.ink2, fontStyle: 'italic' }}
            aria-label="Home">‹</button>
          <button
            disabled={currentHole === 1}
            onClick={() => currentHole > 1 && setCurrentHole(currentHole - 1)}
            style={{
              background: 'transparent', border: 'none', cursor: currentHole === 1 ? 'default' : 'pointer',
              padding: '2px 4px', fontFamily: fonts.mono, fontSize: 14, color: currentHole === 1 ? P.ink3 : P.ink, fontWeight: 700,
            }}>‹</button>
          <div style={{ minWidth: 60, textAlign: 'center' }}>
            <div style={{ fontFamily: fonts.serif, fontSize: 17, fontWeight: 700, fontStyle: 'italic', lineHeight: 1 }}>
              Hole {labelHole(currentHole)}
            </div>
            <div style={{ fontFamily: fonts.mono, fontSize: 9, fontWeight: 700, color: P.ink2, letterSpacing: 1.2, marginTop: 2 }}>
              PAR {cur.par} · {dist.fmt(cur.yds)} {dist.unit.toUpperCase()}
            </div>
          </div>
          <button
            disabled={currentHole === 9}
            onClick={() => currentHole < 9 && setCurrentHole(currentHole + 1)}
            style={{
              background: 'transparent', border: 'none', cursor: currentHole === 9 ? 'default' : 'pointer',
              padding: '2px 4px', fontFamily: fonts.mono, fontSize: 14, color: currentHole === 9 ? P.ink3 : P.ink, fontWeight: 700,
            }}>›</button>
        </div>

        {/* lying stamp */}
        <div style={{ ...paperCard, padding: '6px 10px',
          fontFamily: fonts.mono, fontSize: 10, fontWeight: 700, color: P.flag,
          letterSpacing: 1.2, textTransform: 'uppercase' }}>
          Lying {shots.length} {shots.length > 0 ? `of ${shots.length}` : ''}
        </div>
      </div>

      {/* Distance card */}
      <div style={{
        position: 'absolute', top: STATUS_BAR_H + 66, left: 12, zIndex: 30,
        ...paperCard, padding: '12px 16px 10px', minWidth: 168,
      }}>
        <div style={{ fontFamily: fonts.mono, fontSize: 9, fontWeight: 700, color: P.ink2, letterSpacing: 1.4, textTransform: 'uppercase' }}>To pin</div>
        <div style={{
          fontFamily: fonts.serif, fontSize: 64, fontWeight: 700, letterSpacing: -2.5,
          lineHeight: 0.85, color: P.ink, fontVariantNumeric: 'tabular-nums', marginTop: 2,
        }}>
          {dist.fmt(toPin)}
          <span style={{ fontFamily: fonts.mono, fontSize: 14, fontWeight: 700, color: P.ink2, marginLeft: 4, letterSpacing: 0 }}>{dist.unit}</span>
        </div>
        <div style={{
          marginTop: 8, paddingTop: 8, borderTop: `1px solid ${P.rule}`,
          display: 'flex', justifyContent: 'space-between', gap: 12,
          fontFamily: fonts.mono, fontVariantNumeric: 'tabular-nums',
        }}>
          <div>
            <div style={{ fontSize: 8, color: P.ink3, fontWeight: 700, letterSpacing: 1.2 }}>FRONT</div>
            <div style={{ fontSize: 14, color: P.ink, fontWeight: 700, marginTop: 1 }}>{dist.fmt(toPin - 14)}</div>
          </div>
          <div>
            <div style={{ fontSize: 8, color: P.ink3, fontWeight: 700, letterSpacing: 1.2 }}>BACK</div>
            <div style={{ fontSize: 14, color: P.ink, fontWeight: 700, marginTop: 1 }}>{dist.fmt(toPin + 14)}</div>
          </div>
        </div>
      </div>

      {/* corner stamp */}
      <div style={{
        position: 'absolute', top: STATUS_BAR_H + 74, right: 18, zIndex: 25,
        fontFamily: fonts.mono, fontSize: 10, fontWeight: 700,
        color: '#fff', letterSpacing: 1.4, textShadow: '0 1px 3px rgba(0,0,0,0.7)',
      }}>N ↑</div>

      {/* Bottom paper sheet */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0, zIndex: 30,
        background: P.paper, color: P.ink,
        borderTopLeftRadius: 28, borderTopRightRadius: 28,
        padding: '18px 20px 32px',
        boxShadow: '0 -8px 40px rgba(0,0,0,0.5)',
        backgroundImage: `repeating-linear-gradient(45deg, transparent 0 11px, rgba(${P.inkRgb},0.018) 11px 12px)`,
      }}>
        {/* drag handle */}
        <div style={{ width: 40, height: 3, background: P.rule, borderRadius: 2, margin: '0 auto 14px' }} />

        {/* selected club */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
          <div>
            <div style={{ fontFamily: fonts.mono, fontSize: 10, color: P.ink3, fontWeight: 700, letterSpacing: 1.4, textTransform: 'uppercase' }}>Selected</div>
            <div style={{ fontFamily: fonts.serif, fontSize: 22, fontWeight: 700, letterSpacing: -0.3, fontStyle: 'italic', color: P.ink, marginTop: 2 }}>
              {selectedClubMeta.name} <span style={{ fontStyle: 'normal', fontFamily: fonts.mono, fontSize: 12, color: P.ink3, fontWeight: 600 }}>avg {dist.fmt(selectedClubMeta.y)} {dist.unit}</span>
            </div>
          </div>
          <button onClick={undoShot} disabled={shots.length === 0}
            style={{
              background: 'transparent', border: `1px solid ${shots.length ? P.ink : P.ink3}`,
              color: shots.length ? P.ink : P.ink3, padding: '4px 10px',
              fontFamily: fonts.mono, fontSize: 10, fontWeight: 700, letterSpacing: 1.2, textTransform: 'uppercase',
              cursor: shots.length ? 'pointer' : 'default', borderRadius: 2,
            }}>↺ Undo</button>
        </div>

        {/* club row */}
        <div style={{
          display: 'flex', gap: 0, overflowX: 'auto', padding: '6px 0',
          borderTop: `1.5px solid ${P.ink}`,
          borderBottom: `1px solid ${P.ink}`,
          maskImage: 'linear-gradient(90deg, transparent 0%, #000 6%, #000 94%, transparent 100%)',
        }}>
          {CLUBS.map((club, i) => {
            const sel = club.c === selectedClub;
            return (
              <div key={club.c} onClick={() => setSelectedClub(club.c)} style={{
                flex: '0 0 auto', minWidth: 50, padding: '8px 4px',
                borderRight: i < CLUBS.length - 1 ? `1px solid ${P.rule}` : 'none',
                textAlign: 'center', cursor: 'pointer',
                background: sel ? P.ink : 'transparent',
                color: sel ? P.paper : P.ink,
              }}>
                <div style={{ fontFamily: fonts.serif, fontSize: 16, fontWeight: 700, fontStyle: 'italic' }}>{club.c}</div>
                <div style={{
                  fontFamily: fonts.mono, fontSize: 9, fontWeight: 600, marginTop: 2,
                  opacity: sel ? 0.85 : 0.65, fontVariantNumeric: 'tabular-nums',
                }}>{dist.fmt(club.y)}{dist.short}</div>
              </div>
            );
          })}
        </div>

        {/* mark button */}
        <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
          <button onClick={undoShot} disabled={shots.length === 0}
            style={{
              width: 50, height: 50, borderRadius: 4, border: `1.5px solid ${shots.length ? P.ink : P.ink3}`,
              background: 'transparent',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: shots.length ? P.ink : P.ink3,
              fontFamily: fonts.serif, fontSize: 22, fontStyle: 'italic',
              cursor: shots.length ? 'pointer' : 'default',
            }}>↺</button>
          <button onClick={markShot}
            style={{
              flex: 1, height: 50, background: P.flag, color: P.paper,
              borderRadius: 4, display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: fonts.serif, fontSize: 20, fontWeight: 700, letterSpacing: 0.3,
              boxShadow: '0 2px 0 rgba(0,0,0,0.25)',
              border: 'none', cursor: 'pointer',
            }}>
            <span style={{ fontStyle: 'italic', fontWeight: 400, marginRight: 6, opacity: 0.85 }}>Log</span>
            shot
          </button>
          <button
            style={{
              width: 50, height: 50, borderRadius: 4, border: `1.5px solid ${P.ink}`,
              background: 'transparent',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: P.flag, fontFamily: fonts.serif, fontSize: 18, cursor: 'pointer',
            }}>⚠</button>
        </div>

        {/* hole nav hint */}
        <div style={{
          textAlign: 'center', marginTop: 12, fontFamily: fonts.mono,
          fontSize: 9, color: P.ink3, fontWeight: 700, letterSpacing: 1.4,
        }}>{currentHole > 1 ? '‹ SWIPE FOR PREV' : ''}{currentHole > 1 && currentHole < 9 ? ' · ' : ''}{currentHole < 9 ? `NEXT HOLE ›` : ''}</div>
      </div>
    </Frame>
  );
}

Object.assign(window, { ActiveRound, CLUBS });
