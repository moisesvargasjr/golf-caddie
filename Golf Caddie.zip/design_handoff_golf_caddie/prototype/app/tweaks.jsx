// tweaks.jsx — Tweaks panel for the prototype.
// Uses my useScorecard() for state; TweaksPanel from starter for chrome.

function AppTweaks() {
  const { tweaks, setTweak } = useScorecard();
  const set = (k) => (v) => setTweak(k, v);

  return (
    <TweaksPanel title="Tweaks">
      <TweakSection label="Theme">
        <TweakRadio
          label="Mode"
          value={tweaks.themeMode}
          options={[
            { label: 'Auto', value: 'auto' },
            { label: 'Light', value: 'light' },
            { label: 'Dark', value: 'dark' },
          ]}
          onChange={set('themeMode')}
        />
      </TweakSection>

      <TweakSection label="Palette">
        <TweakColor
          label="Ink"
          value={tweaks.inkHue}
          options={[
            { label: 'Forest green', value: 'green', color: '#1B3A29' },
            { label: 'Black',        value: 'black', color: '#1F1B14' },
            { label: 'Navy',         value: 'navy',  color: '#1A2A4A' },
          ]}
          onChange={set('inkHue')}
        />
        <TweakColor
          label="Accent"
          value={tweaks.accent}
          options={[
            { label: 'Vintage red', value: 'vintage-red', color: '#A8392A' },
            { label: 'Amber',       value: 'amber',       color: '#C77721' },
            { label: 'Forest',      value: 'forest',      color: '#3A6B3C' },
          ]}
          onChange={set('accent')}
        />
      </TweakSection>

      <TweakSection label="Formatting">
        <TweakRadio
          label="Units"
          value={tweaks.units}
          options={[
            { label: 'Yards',  value: 'yds' },
            { label: 'Meters', value: 'm' },
          ]}
          onChange={set('units')}
        />
        <TweakRadio
          label="Hole numerals"
          value={tweaks.numerals}
          options={[
            { label: 'Roman', value: 'roman' },
            { label: 'Arabic', value: 'arabic' },
          ]}
          onChange={set('numerals')}
        />
      </TweakSection>
    </TweaksPanel>
  );
}

Object.assign(window, { AppTweaks });
